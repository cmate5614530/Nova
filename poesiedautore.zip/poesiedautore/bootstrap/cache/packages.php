<?php return array (
  'cartalyst/tags' => 
  array (
    'providers' => 
    array (
      0 => 'Cartalyst\\Tags\\TagsServiceProvider',
    ),
  ),
  'codebykyle/calculated-field' => 
  array (
    'providers' => 
    array (
      0 => 'Codebykyle\\CalculatedField\\FieldServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'laravel/nova' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Nova\\NovaCoreServiceProvider',
    ),
    'aliases' => 
    array (
      'Nova' => 'Laravel\\Nova\\Nova',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'optimistdigital/nova-multiselect-field' => 
  array (
    'providers' => 
    array (
      0 => 'OptimistDigital\\MultiselectField\\FieldServiceProvider',
    ),
  ),
  'optimistdigital/nova-translations-loader' => 
  array (
    'providers' => 
    array (
    ),
    'aliases' => 
    array (
    ),
  ),
  'palauaandsons/nova-tags-field' => 
  array (
    'providers' => 
    array (
      0 => 'PalauaAndSons\\TagsField\\TagsFieldServiceProvider',
    ),
  ),
  'r64/nova-image-cropper' => 
  array (
    'providers' => 
    array (
      0 => 'R64\\NovaImageCropper\\FieldServiceProvider',
    ),
  ),
  'saumini/count' => 
  array (
    'providers' => 
    array (
      0 => 'Saumini\\Count\\FieldServiceProvider',
    ),
  ),
  'spatie/eloquent-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\EloquentSortable\\EloquentSortableServiceProvider',
    ),
  ),
  'spatie/laravel-tags' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Tags\\TagsServiceProvider',
    ),
  ),
  'spatie/laravel-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Translatable\\TranslatableServiceProvider',
    ),
  ),
  'spatie/nova-tags-field' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\TagsField\\TagsFieldServiceProvider',
    ),
  ),
);